#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    bool x=false;

    printf("%d\n",x);
    return 0;
}
