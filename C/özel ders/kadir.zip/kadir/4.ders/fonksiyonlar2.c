#include <stdio.h>
#include <stdlib.h>

int kare_alma(int num){  
    printf("Kare alma fonksiyonu\n");
    printf("%d\n", num*num);
    return num * num;    
}

int main(){
    int num ; 
    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Karesi: %d\n", kare_alma(num));
    return 0;
}