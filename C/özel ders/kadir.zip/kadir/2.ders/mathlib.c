#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    /*
    ceil floor sqrt pow abs
    */
    printf("%f\n",ceil(4.3));  // 5
    printf("%f\n",floor(4.9));  // 4
    printf("%f\n",sqrt(64)); // 8
    printf("%f\n",pow(3,5)); 
    printf("%d\n",abs(-15));

    return 0;
}
