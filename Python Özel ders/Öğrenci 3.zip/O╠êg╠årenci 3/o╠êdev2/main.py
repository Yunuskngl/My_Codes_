print("First, you should play the boring adventure!")
import boring_adventure
print("Second, you should play the fun adventure!")
import fun_adventure
print("Uh oh!  There's no more adventures to play!")