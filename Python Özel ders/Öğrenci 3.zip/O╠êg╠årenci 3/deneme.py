a = 5
print(a)

a = "deneme bir iki"

sayı  =10
sayı = 11

print(a)