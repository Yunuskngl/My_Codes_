#include <iostream>  // input output stream 
#include <stdlib.h>
#include <stdio.h>

using namespace std;

int main(){

    /*
    int a = 1; 
    float b = 4.36;
    char c = 'A';
    bool d = true;
    string cumle = "hello world";

    printf("%d\n",a);

    cout << a << " " <<  b << c << d << cumle << endl ;


    if(a > 3){
        cout << "a is greater than 3" << endl;
    } 
    else {
        cout << " a is not greater than 3 " <<endl ;
    }

    for(int i= 0 ; i<5 ;i++){
        cout << i << endl;
    }

    int j=0;
    while(j < 5){
        cout << j << endl;
        j++;
    }*/

    int eleman ;

    cout << "lütfen bir sayı giriniz : " << endl;
    cin >> eleman ; 
    cout << "girilen eleman : " << eleman << endl;

    // -2147483647 < int tipinde bir sayının değer aralığı < 2147483647

    return 0 ; 
}

